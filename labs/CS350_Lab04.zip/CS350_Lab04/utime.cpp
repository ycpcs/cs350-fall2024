#ifdef UTIME_TEST
#  include <stdio.h>
#  include <unistd.h>
#endif
#include <cstdint>
#include <cstdlib>
#include <sys/time.h>

uint64_t utime()
{
    struct timeval tv;
    uint64_t result = 0;

    gettimeofday(&tv, nullptr);
    result += (uint64_t(tv.tv_sec) * 1000000);
    result += tv.tv_usec;

    return result;
}

#ifdef UTIME_TEST
int main(void)
{
    uint64_t start, end;

    start = utime();
    printf("Sleeping...\n");
    sleep(1);
    end = utime();

    printf("%lu ms elapsed\n", end - start);

    return 0;
}
#endif
