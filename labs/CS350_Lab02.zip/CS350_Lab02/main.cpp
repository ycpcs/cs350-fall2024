#include <stack>
#include <string>
#include <iostream>
#include <cstdlib>

int main()
{
    std::stack<int> stack;

    while (!std::cin.eof()) {
        std::string tok;
        if (!(std::cin >> tok) || tok == "END") {
            break;
        }

        // Debugging:
        //std::cout << "Token: " << tok << std::endl;

        if (tok == "+") {
            // TODO: plus operator

        } else if (tok == "-") {
            // TODO: minus operator

        } else if (tok == "*") {
            // TODO: times operator

        } else if (tok == "/") {
            // TODO: divide operator

        } else {
            int value = atoi(tok.c_str());

            // TODO: an operand
        }

    }

    // print the final result
    std::cout << "Result: " << stack.top() << std::endl;

    return 0;
}
